<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\GoodsFlow;
use Faker\Generator as Faker;
$factory->define(GoodsFlow::class, function (Faker $faker) {
    return [
        
    ];
});
